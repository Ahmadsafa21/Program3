#include "interface.h"
#include <iostream>

//Ahmad Safa
//This is my main file to be able to run my program

int main()
{
    interface olympics;

    olympics.buildAthletes();
    olympics.getUserInput();
    olympics.display();


    return 0;
}

