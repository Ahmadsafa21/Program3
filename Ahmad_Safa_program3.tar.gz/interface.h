//Ahmad Safa
//This file is responsible for managing my application
#include "vectorDT.h"


class interface
{
    public:
        void buildAthletes();
        void getUserInput();
        void display();

    protected:

        RBT shootingAthletes;
        vectorDT otherAthletes;
};

